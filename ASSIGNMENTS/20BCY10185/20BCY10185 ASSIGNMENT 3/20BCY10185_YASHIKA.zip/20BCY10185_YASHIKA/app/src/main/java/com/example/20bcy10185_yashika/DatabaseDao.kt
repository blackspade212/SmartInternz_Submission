package com.example.20BCY10185_YASHIKA;


import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query


@Dao
interface DatabaseDao{
    @Query("SELECT * FROM my_list")
    fun getAll(): List<User>

    @Query("SELECT * FROM my_list where name= :name")
    suspend fun findByRoll(name:String):User?

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insert(user: User)

    @Delete
    suspend fun delete(user: User)

    @Query("DELETE FROM my_list")
    suspend fun deleteAll()


}