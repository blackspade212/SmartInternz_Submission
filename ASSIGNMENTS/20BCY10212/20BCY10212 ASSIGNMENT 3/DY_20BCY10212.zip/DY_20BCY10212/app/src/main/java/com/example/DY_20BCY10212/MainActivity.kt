package com.example.DY_20BCY10212


import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import com.example.DY_20BCY10212.databinding.ActivityMainBinding
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainActivity : AppCompatActivity() {
    private lateinit var binding : ActivityMainBinding
    private lateinit var appDb: AppDatabase

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding=ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root )
        appDb= AppDatabase.getDatabase(this)
        binding.button1.setOnClickListener{
            submit()

        }
        binding.button2.setOnClickListener {
            show()
        }

    }
    private fun submit(){
     val name=binding.editText.text.toString()
        val location=binding.editText2.text.toString()
        if(name.isNotEmpty()&&location.isNotEmpty())
        {
            val user=User(0L,name, location)
            GlobalScope.launch(Dispatchers.IO)
            {
                appDb.databasedao().insert(user)
            }

            binding.editText.text.clear()
            binding.editText2.text.clear()

            Toast.makeText(this@MainActivity,"Saved",Toast.LENGTH_SHORT).show()
        }else
        {
            Toast.makeText(this@MainActivity,"Enter Data",Toast.LENGTH_SHORT).show()
        }

    }
    private suspend fun display(user: User)
    {
        withContext(Dispatchers.Main){
            binding.tvname.text=user.name
            binding.tvlocation.text=user.location
        }
    }
    private fun show()
    {
        val name=binding.editText3.text.toString()
        if(name.isNotEmpty()){
            lateinit var user:User
            GlobalScope.launch {
                user= appDb.databasedao().findByRoll(name)!!
                display(user)
            }
        }
    }


}