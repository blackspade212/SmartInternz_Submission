package com.example.DY_20BCY10212

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "my_list")
data class User(
    @PrimaryKey(autoGenerate = true)
    val id:Long =0L,
    @ColumnInfo(name="name")
    val name: String,
    @ColumnInfo(name="location")
    val location:String,

    )