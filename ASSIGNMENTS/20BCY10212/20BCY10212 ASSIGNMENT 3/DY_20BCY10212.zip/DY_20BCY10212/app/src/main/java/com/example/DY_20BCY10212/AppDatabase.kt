package com.example.DY_20BCY10212

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.example.DY_20BCY10212.AppDatabase
import com.example.DY_20BCY10212.AppDatabase as AppDatabase1


@Database(entities = [User::class], version = 1)
abstract class AppDatabase :RoomDatabase(){

    abstract fun databasedao(): DatabaseDao
    companion object{
        @Volatile
        private var INSTANCE: AppDatabase1?=null
        fun getDatabase(context : Context): AppDatabase1 {

            var tempInstance= INSTANCE
            if (tempInstance!=null) return tempInstance
            synchronized(this){

                tempInstance=Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase1::class.java,
                    "database"
                ).fallbackToDestructiveMigration()
                    .build()
                INSTANCE=tempInstance
                return tempInstance as AppDatabase
            }
        }
    }
}