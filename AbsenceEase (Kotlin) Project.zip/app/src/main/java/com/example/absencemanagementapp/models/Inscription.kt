package com.example.absencemanagementapp.models

data class Inscription(
    val id: String,
    val module_id: Int,
    val cne: String,
    val promotion: String
) {
}